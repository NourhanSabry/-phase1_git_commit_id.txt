#include <Block.h>
#include <stdio.h>

Block::Block(uint32_t p_block_size)
{
    block_size = p_block_size;
    read_size = 0;
    buffer = (char *)calloc(block_size + 1 + (block_size - (block_size % CryptoPP::AES::BLOCKSIZE)), sizeof(char));
}
bool Block::load(fstream &f)
{
    if (f.is_open())
    {
        f.read(buffer, block_size);
        read_size = f.gcount();
        if (f || f.gcount() > 0)
            return true;
        else
            return false;
    }
    else
        return false;
}
bool Block::store(fstream &f)
{
    if (f.is_open())
    {
        f.write(buffer, read_size);
        return true;
    }
    else
        return false;
}

void Block::encrypt(CryptoPP::byte *key, CryptoPP::byte *iv)
{
// in here , we must call the function  AES , and CBC_Mode and StreamTransformationfilter.
  // 	Encryption
// Create a variable cipherText of type string
std::string cipherText;
// Create Cipher Text
// you can see notice that there is no mode for cipher so we used External mode cipher objects  that allows us to use a separate cipher object for transformations
//create a mode object that holds a reference to an external block cipher object rather than an instance of it.
CryptoPP:AES::Encryption aesEncryption(key,CryptoPP::AES::DEFAULT_KEYLENGTH);  //Alternative //   CryptoPP::AES::Encryption aesEncryption((byte *)key.c_str(), CryptoPP::AES::DEFAULT_KEYLENGTH);
CryptoPP::CBC_Mode_ExternalCipher::Encryption cbcEncryption (aesEncryption,iv); //Alternative //   CryptoPP::CBC_Mode_ExternalCipher::Encryption cbcEncryption(aesEncryption, (byte *)iv.c_str());
// StreamTransformationFilter() is a filter wrapper for StreamTransformation(). as you can see we used it  when pipelining data for stream ciphers and confidentiality-only block ciphers.  as you can see , the filter will optionally handle padding and unpadding when needed.
//the filter handles buffering, blocking, and padding for us.
CryptoPP::StreamTransformationFilter stfEncryptor (cbcEncryption,  new CryptoPP::StringSink(cipherText));
//  the filter will buffer the the buffer to us where reinterpert_cas whixh is a type of casting operator used in C++ wil convert  128 bit-key (16 characters read) into array length  of 16-bit integers (short)
// put message in message.
stfEncryptor.Put (reinterpret_cast < const unsigned char*>(buffer), read_size);
stfEncryptor.MessageEnd();
// Copies the values of cipherText bytes from the location pointed to by source directly to the memory block pointed to by buffer.
memcpy(buffer,cipherText.c_str(), cipherText.size());
// read the size of cipherText.
read_size= cipherText.size();
}

void Block::decrypt(CryptoPP::byte *key, CryptoPP::byte *iv)
{
// Decreption
// // Create Cipher Text
std::string cipher;
 // local string variable.
// // you can see notice that there is no mode for cipher so we used External mode cipher objects  that allows us to use a separate cipher object for transformations
//create a mode object that holds a reference to an external block cipher object rather than an instance of it.
CryptoPP:AES::Decryption aesDecryption(key, CryptoPP::AES::DEFAULT_KEYLENGTH);
CryptoPP::CBC_Mode_ExternalCipher::Decryption cbcDecryption(aesDecryption,iv);
CryptoPP::StreamTransformationFilter stfDecryptor(cbcDecryption, new CryptoPP::StringSink(cipher));
//  the filter will buffer the the buffer to us where reinterpert_cas whixh is a type of casting operator used in C++ wil convert  128 bit-key (16 characters read) into array length  of 16-bit integers (short)
stfDecryptor.Put (reinterpret_cast < const unsigned char*>(buffer), read_size);
stfDecryptor.MessageEnd();
// read the size of the cipher;
read_size= (uint16_t)cipher.size();
// put message in message.
//Copies the values of cipher bytes from the location pointed to by source directly to the memory block pointed to by buffer.
memcpy(buffer,cipher.c_str(), read_size);
}

void Block::print()
{
    cout << buffer;
}
Block::~Block()
{
    if (buffer != NULL)
        free(buffer);
}
