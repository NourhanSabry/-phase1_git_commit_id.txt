#include <FileSpooler.h>

FileSpooler::FileSpooler(const char *p_file_name, uint16_t p_block_size, bool truncate)
{
    if (truncate)
        f.open(p_file_name, ios::in | ios::out | ios::trunc);
    else
        f.open(p_file_name, ios::in | ios::out);
    block_size = p_block_size;
}
Block *FileSpooler::getNextBlock()
{
    Block *b = new Block(block_size);
    //creating a pointer to a new object of the class block.
    if (b->load(f)){
    	return b; 
    //calling the load function from the block class to open the file and manage to move to the next block.
    }
    else {
    	delete b; 
    //delete it and return null.
    	return NULL;
    }
}
void FileSpooler::appendBlock(Block *b)
{
    b->store(f);
}

FileSpooler::~FileSpooler()
{
    if (f.is_open())
        f.close();
}
