#include <SafeBox.h>

SafeBox::SafeBox()
{
}
SafeBox::~SafeBox()
{
}
SafeBoxImport::SafeBoxImport()
{
}
void SafeBoxImport::process(char *input_file,
                            char *output_file,
                            char *working_dir,
                            char *key_file,
                            uint16_t block_size,
                            uint16_t shreds)
{
    printf("Import file\n");
    //print that the file will be imported.
    char k[1024];
    //create an array of characters for the path.
    memset(k,0,1024);
    //initializing the path.
    sprintf("%s/%s",working_dir,output_file);
    char iv[1024];
    //create an array of characters for the initialization vector.
    memset(iv,0,1024);
    ///initializing the initialization vector.
    sprintf("%s/%s.iv",working_dir,output_file);
    ShredManager sm(k, block_size, shreds, true);
    //calling the ShredManager function.
    FileSpooler fs(input_file, block_size, false);
    //calling the FileSpooler function.
    sm.encrypt(&fs,key_file,iv);
    
}
SafeBox *SafeBoxImport::clone()
{
    return new SafeBoxImport();
}
SafeBoxImport::~SafeBoxImport()
{
}

SafeBoxExport::SafeBoxExport()
{
}
void SafeBoxExport::process(char *input_file,
                            char *output_file,
                            char *working_dir,
                            char *key_file,
                            uint16_t block_size,
                            uint16_t shreds)
{
    printf("Export file\n");
    //print that the file will be exported.
    char k[1024];
    //create an array of characters for the path.
    memset(k,0,1024);
    //initializing the path.
    sprintf("%s/%s",working_dir,input_file);
    char iv[1024];
    //create an array of characters for the initialization vector.
    memset(iv,0,1024);
    //initializing the initialization vector.
    sprintf("%s/%s.iv",working_dir,input_file);
    ShredManager sm(k, block_size, shreds, false);
    //calling the ShredManager function.
    FileSpooler fs(input_file, block_size, true);
    //calling the FileSpooler function.
    sm.decrypt(&fs,key_file,iv);
}
SafeBox *SafeBoxExport::clone()
{
    return new SafeBoxExport();
}
SafeBoxExport::~SafeBoxExport()
{
}
