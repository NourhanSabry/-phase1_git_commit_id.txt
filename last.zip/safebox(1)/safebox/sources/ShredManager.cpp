#include <ShredManager.h>

ShredManager::ShredManager(char *p_file_name, uint16_t p_block_size, uint16_t p_shred_count, bool truncate)
{
    shred_count = p_shred_count;
    shreds = (Shred **)calloc(shred_count, sizeof(Shred *));
    for (char i = 0; i < shred_count; i++)
    {
        string str = p_file_name;
        //assigning the file name to another string.
        str.insert(str.find("."),i+"A",1);
        //naming the shred files with a,b,c.
        if(truncate)
        //when truncate is true means in the encryption process.
            shreds[i] = new Shred (str.c_str(), p_block_size, truncate);
        //creating a shred in every loop with the same block size.
        else
        //when truncate is false means in the decryption process.
            shreds[i] = new Shred (str.c_str(), (p_block_size+16)&~15, truncate);
        //creating a shred in every loop with different block size as it changes after the encryption.
    }
}
bool ShredManager::encrypt(FileSpooler *fileSpooler, const char *key_file_name, const char *iv_file_name)
{
 // 	key and IV setup
/*byte iv [AES::BLOCKSIZE];
memset(iv,0x00,AES::BLOCKSIZE)
byte key [AES::DEFAULTLENGTH];
memset(key,0x00,AES::DEFAULTLENGTH);
*/
// AES encryption uses a secret key of a variable length (128-bit, 196-bit or 256-   
    //bit). This key is secretly exchanged between two parties before communication   
    //begins. DEFAULT_KEYLENGTH= 16 bytes
byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], iv[ CryptoPP::AES::BLOCKSIZE ];
    memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
    
AutoSeededRandomPool png;

// read key
std:: ifstream key_f;// Stream classes to read from the key file
key_f.open(key_file_name, std::ios::in);  // the mode of the key file is in which enables the file to open for input operations

if(key_f.is_open()) // To check if a file stream was successful opening a file.
{
    key_f.read(reinterpret_cast<char*>(key),sizeof(key)); // read the key
    key_f.close(); // we called the stream member function close to close it so that the operating system is notified and its resources become available again. 
}

// random generate block
png.GenerateBlock(iv,sizeof(iv));
Block *bl = fileSpooler->getNextBlock();  // call the function getNextblock from file spooler and assigin it to bl that is a pointer to the class Block.
// I have to do a loop here  because I nedd the following process to be reaped which is printing the bl , call encrypt function from the Block class ,  and fetch the nextblock from the shreds by using Get nextBlock 
for (int i=0; bl!=NULL; i++)
{
    std:: cout << bl << std::endl; // print bl
    bl-> encrypt (key,iv); // call the function encrypt from the block.cpp
    *(shreds[i%shred_count])<< *(bl); // this here cout the the shreads 1,2,3 to the number of the shreds  wanted and and store the block in , we used modulus here to be sure it will return to zero.
    delete(bl); // operator delete(bl) in order to deallocates memory from heap.
    bl = fileSpooler->getNextBlock(); // get the next block from any shred 
}

// write iv
std::ofstream iv_f; // Stream classes to write on the iv file
iv_f.open(iv_file_name, std::ios::out | ios::trunc); // the mode of the key file is out which enables the file to open for output operations
if(iv_f.is_open())  // To check if a file stream was successful opening a file.
{
    iv_f.write(reinterpret_cast<char*>(iv),sizeof(iv)); // write the iv
    iv_f.close();//close the iv_f
}

    return true;
}
bool ShredManager::decrypt(FileSpooler *fileSpooler, const char *key_file_name, const char *iv_file_name)
{
     // 	key and IV setup
/*byte iv [AES::BLOCKSIZE];
memset(iv,0x00,AES::BLOCKSIZE);
byte key [AES::DEFAULTLENGTH];
memset(key,0x00,AES::DEFAULTLENGTH);*/
	byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], iv[ CryptoPP::AES::BLOCKSIZE ];
    memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
    
AutoSeededRandomPool png;

// read key
std:: ifstream key_f;
key_f.open(key_file_name, std::ios::in);

if(key_f.is_open())
{
    key_f.read(reinterpret_cast<char*>(key),sizeof(key));
    key_f.close();
}
// read iv
std::ifstream iv_f;
iv_f.open(iv_file_name, std::ios::in);
if(iv_f.is_open())
{
    iv_f.read(reinterpret_cast<char*>(iv),sizeof(iv));
    iv_f.close();
}



Block *bl = shreds[0]->getNextBlock();
for (int i=1 ;bl!=NULL; i++)
{
    bl->decrypt(key,iv); // call the decrypt function from the Block Class
    fileSpooler -> appendBlock(bl); // call the appendBlock from the file spooler
delete (bl);// delte the bl from the heap
bl = shreds[i%shred_count]->getNextBlock(); // get the next block from the shreds and store them in the bl.
}
    return false;
}
ShredManager::~ShredManager()
{
    for (int i = 0; i < shred_count; i++)
        delete (shreds[i]);
    free(shreds);
}
